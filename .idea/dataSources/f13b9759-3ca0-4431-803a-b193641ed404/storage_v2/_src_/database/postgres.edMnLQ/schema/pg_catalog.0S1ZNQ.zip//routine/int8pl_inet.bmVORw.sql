create function int8pl_inet(bigint, inet) returns inet
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN ($2 + $1);

comment on function int8pl_inet(bigint, inet) is 'implementation of + operator';

alter function int8pl_inet(bigint, inet) owner to postgres;

